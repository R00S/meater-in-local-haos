package com.apptionlabs.meater_app.cloud.requests;

import gg.a;
import gg.c;

/* loaded from: /tmp/meat/meat/classes.dex */
public class CloudStatusRequest {

    @c("os_version")
    @a
    public String osVersion;

    @a
    public String platform;

    @a
    public String version;
}
