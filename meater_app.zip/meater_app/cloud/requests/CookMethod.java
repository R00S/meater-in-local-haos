package com.apptionlabs.meater_app.cloud.requests;

/* loaded from: /tmp/meat/meat/classes.dex */
public class CookMethod {
    public int id;
    public String name;
}
