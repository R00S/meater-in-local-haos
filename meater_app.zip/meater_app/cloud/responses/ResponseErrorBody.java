package com.apptionlabs.meater_app.cloud.responses;

/* loaded from: /tmp/meat/meat/classes.dex */
public class ResponseErrorBody {
    public int errorCode;
    public String message;
}
