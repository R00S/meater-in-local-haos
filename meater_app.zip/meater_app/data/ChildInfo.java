package com.apptionlabs.meater_app.data;

/* loaded from: /tmp/meat/meat/classes.dex */
public class ChildInfo {
    private String name = "";

    public String getName() {
        return this.name;
    }

    public void setName(String str) {
        this.name = str;
    }
}
