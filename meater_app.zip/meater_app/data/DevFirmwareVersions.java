package com.apptionlabs.meater_app.data;

import com.apptionlabs.meater_app.versions.FirmwareInfo;
import java.util.ArrayList;

/* loaded from: /tmp/meat/meat/classes.dex */
public class DevFirmwareVersions {
    public ArrayList<FirmwareInfo> plus = new ArrayList<>();
    public ArrayList<FirmwareInfo> block = new ArrayList<>();
}
