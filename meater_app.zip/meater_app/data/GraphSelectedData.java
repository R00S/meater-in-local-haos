package com.apptionlabs.meater_app.data;

/* loaded from: /tmp/meat/meat/classes.dex */
public class GraphSelectedData {
    public String ambientTemperature;
    public String internalTemperature;
    public long timeStamp;
    public String timeTemperature;
}
