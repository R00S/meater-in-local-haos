package com.apptionlabs.meater_app.data;

import gg.c;

/* loaded from: /tmp/meat/meat/classes.dex */
public class OfferBasePairDevices {

    @c("have_meater_block")
    @gg.a
    public boolean haveMeaterBlock;

    @c("have_meater_plus")
    @gg.a
    public boolean haveMeaterPlus;

    @c("have_meater_probe")
    @gg.a
    public boolean haveMeaterProbe;
}
