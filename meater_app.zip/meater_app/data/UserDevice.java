package com.apptionlabs.meater_app.data;

/* loaded from: /tmp/meat/meat/classes.dex */
public class UserDevice {
    public String locale = com.apptionlabs.meater_app.app.a.t();
}
