package com.apptionlabs.meater_app.meatCutStructure;

/* loaded from: /tmp/meat/meat/classes.dex */
public class LegacyMeatMapping {
    public int cutID;
    public int legacyCut;
    public int legacyMeat;
}
