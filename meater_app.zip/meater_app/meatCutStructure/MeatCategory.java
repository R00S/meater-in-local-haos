package com.apptionlabs.meater_app.meatCutStructure;

import gg.c;
import java.util.ArrayList;

/* loaded from: /tmp/meat/meat/classes.dex */
public class MeatCategory extends MeatModel {
    public String colourHex;

    @c("animals")
    public ArrayList<Meat> meats = new ArrayList<>();
}
