package com.apptionlabs.meater_app.meatCutStructure;

import java.util.ArrayList;

/* loaded from: /tmp/meat/meat/classes.dex */
public class MeatCutType extends MeatModel {
    public ArrayList<SearchableMeatCut> cuts = new ArrayList<>();
    public Meat meat;
}
