package com.apptionlabs.meater_app.meatCutStructure;

import java.util.ArrayList;
import java.util.HashMap;

/* loaded from: /tmp/meat/meat/classes.dex */
public class MeatCuts {
    public ArrayList<MeatCategory> categories = new ArrayList<>();
    public HashMap<String, ArrayList<MeatLocaleExclusion>> localeExclusions = new HashMap<>();
}
