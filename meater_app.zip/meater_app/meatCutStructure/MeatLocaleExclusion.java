package com.apptionlabs.meater_app.meatCutStructure;

/* loaded from: /tmp/meat/meat/classes.dex */
public class MeatLocaleExclusion {
    public Integer cutId;
    public Integer id;
}
