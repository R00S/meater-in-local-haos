package com.apptionlabs.meater_app.model;

/* loaded from: /tmp/meat/meat/classes.dex */
public class TabletDevice extends MEATERDevice {
}
