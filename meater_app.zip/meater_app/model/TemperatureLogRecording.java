package com.apptionlabs.meater_app.model;

/* loaded from: /tmp/meat/meat/classes.dex */
public class TemperatureLogRecording {

    @gg.a
    public int ambient;

    @gg.a
    public int internal;

    public TemperatureLogRecording(int i10, int i11) {
        this.internal = i10;
        this.ambient = i11;
    }
}
