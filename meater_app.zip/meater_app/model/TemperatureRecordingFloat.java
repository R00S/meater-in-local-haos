package com.apptionlabs.meater_app.model;

/* loaded from: /tmp/meat/meat/classes.dex */
public class TemperatureRecordingFloat {
    public float ambient;
    public float internal;

    public TemperatureRecordingFloat(float f10, float f11) {
        this.internal = f10;
        this.ambient = f11;
    }
}
