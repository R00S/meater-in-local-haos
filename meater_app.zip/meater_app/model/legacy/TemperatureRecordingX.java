package com.apptionlabs.meater_app.model.legacy;

/* loaded from: /tmp/meat/meat/classes.dex */
public class TemperatureRecordingX {
    public int ambient;
    public int internal;

    public TemperatureRecordingX(int i10, int i11) {
        this.internal = i10;
        this.ambient = i11;
    }
}
