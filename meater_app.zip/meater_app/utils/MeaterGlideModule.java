package com.apptionlabs.meater_app.utils;

import kotlin.Metadata;
import s9.a;

/* compiled from: MeaterGlideModule.kt */
@Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\b\u0007\u0018\u00002\u00020\u0001B\u0007¢\u0006\u0004\b\u0002\u0010\u0003¨\u0006\u0004"}, d2 = {"Lcom/apptionlabs/meater_app/utils/MeaterGlideModule;", "Ls9/a;", "<init>", "()V", "app_playstoreLiveRelease"}, k = 1, mv = {1, 9, 0})
/* loaded from: /tmp/meat/meat/classes.dex */
public final class MeaterGlideModule extends a {
}
