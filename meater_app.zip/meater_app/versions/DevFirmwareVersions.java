package com.apptionlabs.meater_app.versions;

import java.util.ArrayList;

/* loaded from: /tmp/meat/meat/classes.dex */
public class DevFirmwareVersions {
    public ArrayList<FirmwareInfo> plus = new ArrayList<>();
    public ArrayList<FirmwareInfo> se = new ArrayList<>();
    public ArrayList<FirmwareInfo> block = new ArrayList<>();
    public ArrayList<FirmwareInfo> plusV2 = new ArrayList<>();
    public ArrayList<FirmwareInfo> blockV2 = new ArrayList<>();
}
