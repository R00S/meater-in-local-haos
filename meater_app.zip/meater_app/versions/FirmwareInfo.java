package com.apptionlabs.meater_app.versions;

/* loaded from: /tmp/meat/meat/classes.dex */
public class FirmwareInfo {
    public String crc;
    public String url;
    public String version;

    /* loaded from: /tmp/meat/meat/classes.dex */
    public enum Key {
        URL,
        CRC,
        VERSION
    }
}
