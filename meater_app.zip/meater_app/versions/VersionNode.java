package com.apptionlabs.meater_app.versions;

/* loaded from: /tmp/meat/meat/classes.dex */
public class VersionNode {
    public String crc;
    public String minAppVersion;
    public String minVersion;
    public String url;
    public String version;
}
