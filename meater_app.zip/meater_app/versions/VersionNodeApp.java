package com.apptionlabs.meater_app.versions;

/* loaded from: /tmp/meat/meat/classes.dex */
public class VersionNodeApp {
    public String news;
    public int permittedSkips;
    public String version;
}
