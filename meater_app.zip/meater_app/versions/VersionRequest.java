package com.apptionlabs.meater_app.versions;

/* loaded from: /tmp/meat/meat/classes.dex */
public class VersionRequest {
    public DeviceJson device = new DeviceJson();
}
