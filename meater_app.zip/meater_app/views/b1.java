package com.apptionlabs.meater_app.views;

import android.graphics.Typeface;
import com.apptionlabs.meater_app.model.Probe;
import java.util.ArrayList;
import java.util.Hashtable;

/* compiled from: MeaterSingleton.java */
/* loaded from: /tmp/meat/meat/classes.dex */
public class b1 {

    /* renamed from: a, reason: collision with root package name */
    public static ArrayList<Probe> f10461a = new ArrayList<>();

    /* renamed from: b, reason: collision with root package name */
    public static boolean f10462b = false;

    /* renamed from: c, reason: collision with root package name */
    public static String f10463c = "";

    /* renamed from: d, reason: collision with root package name */
    public static int f10464d = 0;

    /* renamed from: e, reason: collision with root package name */
    public static boolean f10465e = false;

    /* renamed from: f, reason: collision with root package name */
    public static float f10466f = 3.0f;

    /* renamed from: g, reason: collision with root package name */
    public static float f10467g = 1080.0f;

    /* renamed from: h, reason: collision with root package name */
    public static boolean f10468h = false;

    /* renamed from: i, reason: collision with root package name */
    public static float f10469i = 1970.0f;

    /* renamed from: j, reason: collision with root package name */
    private static Hashtable<String, Typeface> f10470j = new Hashtable<>();

    /* renamed from: k, reason: collision with root package name */
    public static boolean f10471k = false;

    /* renamed from: l, reason: collision with root package name */
    public static boolean f10472l = false;

    /* renamed from: m, reason: collision with root package name */
    public static int f10473m = 0;

    /* renamed from: n, reason: collision with root package name */
    public static boolean f10474n = false;

    /* renamed from: o, reason: collision with root package name */
    public static boolean f10475o = false;

    /* renamed from: p, reason: collision with root package name */
    public static String f10476p = "1.3.63";

    /* renamed from: q, reason: collision with root package name */
    public static boolean f10477q = false;

    /* renamed from: r, reason: collision with root package name */
    public static String f10478r = "";

    /* renamed from: s, reason: collision with root package name */
    public static boolean f10479s = false;

    /* renamed from: t, reason: collision with root package name */
    public static boolean f10480t = false;

    /* renamed from: u, reason: collision with root package name */
    public static boolean f10481u = false;

    /* renamed from: v, reason: collision with root package name */
    public static boolean f10482v = true;

    /* renamed from: w, reason: collision with root package name */
    public static int f10483w = 0;

    /* renamed from: x, reason: collision with root package name */
    public static boolean f10484x = false;

    /* renamed from: y, reason: collision with root package name */
    public static boolean f10485y = false;

    /* renamed from: z, reason: collision with root package name */
    public static boolean f10486z = false;
    public static boolean A = false;
    public static boolean B = false;

    public static void a() {
        f10462b = false;
        f10463c = "";
        f10464d = 0;
        f10465e = false;
        f10466f = 3.0f;
        f10467g = 1080.0f;
        f10468h = false;
        f10469i = 1970.0f;
        f10470j = new Hashtable<>();
        f10471k = false;
        f10472l = false;
        f10473m = 0;
        f10474n = false;
        f10475o = false;
        f10476p = "1.3.63";
        f10477q = false;
        f10478r = "";
        f10479s = false;
        f10480t = false;
        f10481u = false;
        f10484x = false;
        f10485y = false;
        A = false;
        f10486z = false;
        s6.d.f17849e = false;
        B = false;
        f10461a = new ArrayList<>();
    }
}
