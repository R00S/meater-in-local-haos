package com.apptionlabs.meater_app.views;

/* compiled from: R8$$SyntheticClass */
/* loaded from: /tmp/meat/meat/classes.dex */
public final /* synthetic */ class h1 {
}
