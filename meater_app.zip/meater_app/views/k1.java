package com.apptionlabs.meater_app.views;

/* JADX INFO: Access modifiers changed from: package-private */
/* compiled from: ScrollViewListener.java */
/* loaded from: /tmp/meat/meat/classes.dex */
public interface k1 {
    void b(ScrollViewExt scrollViewExt, int i10, int i11, int i12, int i13);
}
