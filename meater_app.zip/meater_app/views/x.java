package com.apptionlabs.meater_app.views;

import android.app.Activity;
import android.content.Context;
import android.view.ComponentActivity;
import android.view.t0;
import com.apptionlabs.meater_app.activities.MeaterDetailsActivity;
import com.apptionlabs.meater_app.recipe.ui.recipe.RecipeStepsActivity;
import kotlin.Metadata;
import rk.C0458j;

/* compiled from: DialViews.kt */
@Metadata(d1 = {"\u0000\b\n\u0002\u0018\u0002\n\u0002\b\u0002\u0010\u0001\u001a\u00020\u0000H\n¢\u0006\u0004\b\u0001\u0010\u0002"}, d2 = {"Lj8/j;", "b", "()Lj8/j;"}, k = 3, mv = {1, 9, 0})
/* loaded from: /tmp/meat/meat/classes.dex */
final class x extends wh.o implements vh.a<C0458j> {

    /* renamed from: q, reason: collision with root package name */
    final /* synthetic */ DialViews f10623q;

    /* compiled from: ActivityVM.kt */
    @Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u0010\u0003\u001a\u00020\u0002\"\n\b\u0000\u0010\u0001\u0018\u0001*\u00020\u0000H\n¢\u0006\u0004\b\u0003\u0010\u0004"}, d2 = {"Landroidx/lifecycle/q0;", "T", "Landroidx/lifecycle/t0$b;", "b", "()Landroidx/lifecycle/t0$b;"}, k = 3, mv = {1, 9, 0})
    /* loaded from: /tmp/meat/meat/classes.dex */
    public static final class a extends wh.o implements vh.a<t0.b> {

        /* renamed from: q, reason: collision with root package name */
        final /* synthetic */ android.view.w0 f10624q;

        /* renamed from: r, reason: collision with root package name */
        final /* synthetic */ tm.a f10625r;

        /* renamed from: s, reason: collision with root package name */
        final /* synthetic */ vh.a f10626s;

        /* renamed from: t, reason: collision with root package name */
        final /* synthetic */ vm.a f10627t;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public a(android.view.w0 w0Var, tm.a aVar, vh.a aVar2, vm.a aVar3) {
            super(0);
            this.f10624q = w0Var;
            this.f10625r = aVar;
            this.f10626s = aVar2;
            this.f10627t = aVar3;
        }

        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public final t0.b a() {
            return jm.a.a(this.f10624q, wh.d0.b(C0458j.class), this.f10625r, this.f10626s, (vh.a) null, this.f10627t);
        }
    }

    /* compiled from: ActivityViewModelLazy.kt */
    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u0010\u0003\u001a\u00020\u0002\"\n\b\u0000\u0010\u0001\u0018\u0001*\u00020\u0000H\n"}, d2 = {"Landroidx/lifecycle/q0;", "VM", "Landroidx/lifecycle/v0;", "<anonymous>"}, k = 3, mv = {1, 9, 0})
    /* loaded from: /tmp/meat/meat/classes.dex */
    public static final class b extends wh.o implements vh.a<android.view.v0> {

        /* renamed from: q, reason: collision with root package name */
        final /* synthetic */ ComponentActivity f10628q;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public b(ComponentActivity componentActivity) {
            super(0);
            this.f10628q = componentActivity;
        }

        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public final android.view.v0 a() {
            android.view.v0 y10 = this.f10628q.y();
            wh.m.e(y10, "viewModelStore");
            return y10;
        }
    }

    /* compiled from: ActivityVM.kt */
    @Metadata(d1 = {"\u0000\u000e\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\u0010\u0003\u001a\u00020\u0002\"\n\b\u0000\u0010\u0001\u0018\u0001*\u00020\u0000H\n¢\u0006\u0004\b\u0003\u0010\u0004"}, d2 = {"Landroidx/lifecycle/q0;", "T", "Landroidx/lifecycle/t0$b;", "b", "()Landroidx/lifecycle/t0$b;"}, k = 3, mv = {1, 9, 0})
    /* loaded from: /tmp/meat/meat/classes.dex */
    public static final class c extends wh.o implements vh.a<t0.b> {

        /* renamed from: q, reason: collision with root package name */
        final /* synthetic */ android.view.w0 f10629q;

        /* renamed from: r, reason: collision with root package name */
        final /* synthetic */ tm.a f10630r;

        /* renamed from: s, reason: collision with root package name */
        final /* synthetic */ vh.a f10631s;

        /* renamed from: t, reason: collision with root package name */
        final /* synthetic */ vm.a f10632t;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public c(android.view.w0 w0Var, tm.a aVar, vh.a aVar2, vm.a aVar3) {
            super(0);
            this.f10629q = w0Var;
            this.f10630r = aVar;
            this.f10631s = aVar2;
            this.f10632t = aVar3;
        }

        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public final t0.b a() {
            return jm.a.a(this.f10629q, wh.d0.b(C0458j.class), this.f10630r, this.f10631s, (vh.a) null, this.f10632t);
        }
    }

    /* compiled from: ActivityViewModelLazy.kt */
    @Metadata(d1 = {"\u0000\f\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\u0010\u0003\u001a\u00020\u0002\"\n\b\u0000\u0010\u0001\u0018\u0001*\u00020\u0000H\n"}, d2 = {"Landroidx/lifecycle/q0;", "VM", "Landroidx/lifecycle/v0;", "<anonymous>"}, k = 3, mv = {1, 9, 0})
    /* loaded from: /tmp/meat/meat/classes.dex */
    public static final class d extends wh.o implements vh.a<android.view.v0> {

        /* renamed from: q, reason: collision with root package name */
        final /* synthetic */ ComponentActivity f10633q;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public d(ComponentActivity componentActivity) {
            super(0);
            this.f10633q = componentActivity;
        }

        /* renamed from: b, reason: merged with bridge method [inline-methods] */
        public final android.view.v0 a() {
            android.view.v0 y10 = this.f10633q.y();
            wh.m.e(y10, "viewModelStore");
            return y10;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public x(DialViews dialViews) {
        super(0);
        this.f10623q = dialViews;
    }

    /* renamed from: b, reason: merged with bridge method [inline-methods] */
    public final C0458j a() {
        Activity u10;
        DialViews dialViews = this.f10623q;
        Context context = dialViews.getContext();
        wh.m.e(context, "getContext(...)");
        u10 = dialViews.u(context);
        if (u10 instanceof MeaterDetailsActivity) {
            ComponentActivity componentActivity = (ComponentActivity) u10;
            return (C0458j) ((android.view.q0) new android.view.s0(wh.d0.b(C0458j.class), new b(componentActivity), new a(componentActivity, null, null, bm.a.a(componentActivity))).getValue());
        }
        wh.m.d(u10, "null cannot be cast to non-null type com.apptionlabs.meater_app.recipe.ui.recipe.RecipeStepsActivity");
        RecipeStepsActivity recipeStepsActivity = (RecipeStepsActivity) u10;
        return (C0458j) ((android.view.q0) new android.view.s0(wh.d0.b(C0458j.class), new d(recipeStepsActivity), new c(recipeStepsActivity, null, null, bm.a.a(recipeStepsActivity))).getValue());
    }
}
