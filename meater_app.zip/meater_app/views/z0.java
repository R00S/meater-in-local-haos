package com.apptionlabs.meater_app.views;

import android.animation.ValueAnimator;

/* compiled from: R8$$SyntheticClass */
/* loaded from: /tmp/meat/meat/classes.dex */
public final /* synthetic */ class z0 implements Runnable {

    /* renamed from: q, reason: collision with root package name */
    public final /* synthetic */ ValueAnimator f10640q;

    @Override // java.lang.Runnable
    public final void run() {
        this.f10640q.start();
    }
}
